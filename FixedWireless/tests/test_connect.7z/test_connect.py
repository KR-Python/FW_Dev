import pytest
import os
from FixedWireless.postgis.connect import ODW
from FixedWireless.postgis.queries import build_lit_building_query


@pytest.fixture
def odw():
    return ODW(username='cc_geo_private')


@pytest.fixture
def conn_params(odw):
    return odw.connection_params


@pytest.fixture
def qgis_username():
    return f"qgis{os.getlogin()}"


@pytest.fixture
def lit_building_query():
    test_latitude = 40.7390831
    test_longitude = -73.9913778
    test_distance = 2
    test_limit = 25

    return build_lit_building_query(test_longitude, test_latitude, test_distance, test_limit)


@pytest.fixture
def limit_five():

    return "select buildingid, name, clli from ospi.ne_dw_buildings limit 5"


class TestODW:
    def test__init(self, conn_params):
        assert conn_params.get('user') == 'cc_geo_private'

    def test_connection(self, odw):
        assert not odw.connection.closed

    def test_cursor(self, odw, limit_five):
        odw.cursor.execute(limit_five)
        rows_found = odw.cursor.fetchall()
        assert len(rows_found) == 5
        assert len(rows_found[0]) == 3

    def test_user(self, odw, qgis_username):
        assert odw._qgis_user == qgis_username
        assert odw.user == 'cc_geo_private'

        with pytest.raises(EnvironmentError):
            odw.user = 'ccfodwadmin'

    def test_server_side_cursor(self, odw, limit_five):
        sc = odw.serverSideCursor('test_cursor', refresh=True)
        sc.execute(limit_five)
        rows_found = sc.fetchall()
        assert len(rows_found) == 5

        with pytest.raises(ValueError):
            odw.serverSideCursor('bad_cursor_name')

    def test_sql_to_geo_data_frame(self, odw, lit_building_query):
        gdf = odw.sql_to_GeoDataFrame(lit_building_query, geom_col='pnt_geom')

        assert int(gdf.shape[0]) == 25
        assert all([col_name in gdf.columns.values for col_name in ['candidate_type', 'id', 'cand_dist_km', 'long', 'lat', 'height', 'pnt_geom']])
        assert gdf.iloc[0]['candidate_type'] == 'ospi'